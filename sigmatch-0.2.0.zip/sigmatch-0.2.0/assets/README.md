# assets

## 🍺 Credits

- **logo.svg** made by [Freepik](https://www.freepik.com) from [www.flaticon.com](https://www.flaticon.com).
